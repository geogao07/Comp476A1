﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HumanCharBehaviour : MonoBehaviour
{
    public GameObject target;
    public float viewAngle;
    public float viewRange;
    public float orientationRads;
    public float slowDownThreshold;
    public float goalRotationSpeedRads;
    public float maxRotationSpeedRads;
    public float maxRotationAccelerationRads;
    public float accelerationRads;
    public float timeToTarget;


    //param for static arrive
    float speed = 20.0f;
    float nearSpeed = 10.0f;
    float nearRadius = 20.0f;
    float arrivalRadius = 10.0f;
    float distanceFromTarget;

    public LayerMask targetLayer;
    public LayerMask obstacleLayer;

    float rotationSpeedRads;

    


    [SerializeField] float shortDistance = 1f;
    [SerializeField] float maxVelocityMagnitude = 5f;
    [SerializeField] Vector3 acceleration;
    Vector3 velocity;

    List<Transform> visibleTargets = new List<Transform>();
    // Start is called before the first frame update
    void Start()
    {
        //param for align2
        rotationSpeedRads = 100f;
        slowDownThreshold = 5.0f;
        maxRotationSpeedRads = 2.0f;
        maxRotationAccelerationRads = 1.0f;
        goalRotationSpeedRads = 0.0f;
        
        accelerationRads = 0.1f;
        timeToTarget = 0.0f;

        acceleration = new Vector3(0, 0, 0);
        velocity = new Vector3(0, 0, 0);
        StartCoroutine(FindTargetWithDelay(0.2f));
    }

    // Update is called once per frame
    void Update()

    {

        if (gameObject.layer == 9 || gameObject.layer == 8)
        {
            if (this.target == null)
            {
                GameObject[] freezeList = GameObject.FindGameObjectsWithTag("Freeze");

                if (gameObject.layer == 9 && visibleTargets.Count > 0)
                {
                    float distance = 10000f;
                    foreach (Transform go in visibleTargets)
                    {
                        float tempDistance = Vector3.Distance(go.position, transform.position);
                        if (tempDistance < distance)
                        {
                            target = go.gameObject;
                            distance = tempDistance;
                        }
                    }
                    target.GetComponent<HumanCharBehaviour>().target = gameObject;
                }
                else if (freezeList.Length > 0 && gameObject.layer == 8)
                {
                    foreach (GameObject go in freezeList)
                    {
                        target = freezeList[0];
                    }
                }
                else
                {
                    //implementation of wander
                    Debug.Log("wander here");

                }

            }
            else
            {
                if (gameObject.layer == 9 && (Vector3.Distance(target.transform.position, transform.position) > viewRange || target.layer == 10))
                {
                    this.target.GetComponent<HumanCharBehaviour>().target = null;
                    this.target = null;
                }
                else if (target.layer == 10)
                {
                    Align(target);
                    KinematicArrive(target);
                    if (Unfreeze() || target.layer == 8)
                    {
                        target = null;
                    }
                }
                else
                {
                    Kinematic();
                }
            }
        }
        else if (gameObject.layer == 10)
        {
            gameObject.GetComponent<Rigidbody>().velocity = Vector3.zero;
            target = null;
        }


        if (transform.position.x >= 30.1f && GetComponent<Rigidbody>().velocity.normalized.x >= 0)
            transform.position = new Vector3(-20f, 0f, transform.position.z);
        else if (transform.position.x <= -20.5f && GetComponent<Rigidbody>().velocity.normalized.x <= 0)
            transform.position = new Vector3(30f, 0f, transform.position.z);
        else if (transform.position.z >= 14.9f && GetComponent<Rigidbody>().velocity.normalized.z >= 0)
            transform.position = new Vector3(transform.position.x, 0f, -14.5f);
        else if (transform.position.z <= -14.6f && GetComponent<Rigidbody>().velocity.normalized.z <= 0)
            transform.position = new Vector3(transform.position.x, 0f, 14.8f);
    }

   bool Unfreeze()
    {
        if (target.layer == 10)
        {
            if (Vector3.Distance(target.transform.position, transform.position) <= 1f)
            {
                target.layer = 8;
                target.tag = "Prey";
                return true;
            }
        }
        return false;
    }

    void KinematicArrive(GameObject target)
    {
        distanceFromTarget = (target.transform.position - transform.position).magnitude;
        if (distanceFromTarget > nearRadius)
        {
            Debug.Log("Outside Near Radius " + distanceFromTarget);
            GetComponent<Rigidbody>().velocity = ((target.transform.position - transform.position).normalized * speed);
        }
        else if ((target.transform.position - transform.position).magnitude > arrivalRadius)
        {
            Debug.Log("Inside Near Radius " + distanceFromTarget);
            GetComponent<Rigidbody>().velocity = ((target.transform.position - transform.position).normalized * nearSpeed);
        }
        else
        {
            Debug.Log("Inside Arrive Radius " + distanceFromTarget);
            GetComponent<Rigidbody>().velocity = new Vector3(0.0f, 0.0f, 0.0f);
        }
    }


    IEnumerator FindTargetWithDelay(float delay)
    {
        while (true)
        {
            yield return new WaitForSeconds(delay);
            FindVisibleTargets(gameObject.layer);

        }
    }

    void FindVisibleTargets(int layer)
    {
        visibleTargets.Clear();
        if (layer == 9)
        {
            Collider[] targetInViewRadius = Physics.OverlapSphere(transform.position, viewRange, targetLayer);

            for (int i = 0; i < targetInViewRadius.Length; i++)
            {
                Transform target = targetInViewRadius[i].transform;
                Vector3 direction_to_target = (target.position - transform.position).normalized;

                float disToTarget = Vector3.Distance(transform.position, target.position);

                if (!Physics.Raycast(transform.position, direction_to_target, disToTarget, obstacleLayer))
                {
                    visibleTargets.Add(target);
                }

            }
        }
    }

    Vector3 Direction(Vector3 target)
    {
        return (target - transform.position).normalized;
    }
    Vector3 Direction(GameObject target)
    {
        return (target.transform.position - transform.position).normalized;
    }

    void Kinematic()
    {
        if (gameObject.tag == "Hunter")
        {
            if (GetComponent<Rigidbody>().velocity.magnitude < 5f)
            {
                Debug.Log("A");
                KinematicMoveA();
            }
            else
            {
                Debug.Log("B");
                KinematicMoveB();
            }
        }
        else if (gameObject.tag == "Prey" && target.layer == 9)
        {
            KinematicMoveC();
        }
    }

    void KinematicMoveC()
    {
        if (Vector3.Distance(transform.position, target.transform.position) < shortDistance)
        {
            KinematicLeave(target);
        }
        else
        {
            GetComponent<Rigidbody>().velocity = Vector3.zero;
            AlignBack(target);
            KinematicLeave(target);
        }
    }

    void KinematicLeave(GameObject target)
    {
        gameObject.GetComponent<Rigidbody>().velocity = -KinematicVelocity(target);
    }

    Vector3 KinematicVelocity(GameObject target)
    {
        return maxVelocityMagnitude * Direction(target);
    }
    Vector3 KinematicVelocity(Vector3 target)
    {
        return maxVelocityMagnitude * Direction(target);
    }

    void KinematicMoveA()
    {
        if (Vector3.Distance(target.transform.position, transform.position) <= shortDistance)
        {
            KinematicPursue(target);
        }
        else if (Vector3.Distance(target.transform.position, transform.position) > shortDistance)
        {
            Align(target);
            KinematicPursue(target);
        }
    }

    void KinematicMoveB()
    {
        if (Vector3.Angle(target.transform.position - transform.position, transform.forward) < viewAngle)
        {
            Align(target);
            KinematicPursue(target);
            Debug.Log("if");
        }
        else
        {
           // GetComponent<Rigidbody>().velocity = Vector3.zero;
            Align(target);
            KinematicPursue(target);
            Debug.Log("else");
        }
    }

    void Align(GameObject target)
    {
        //Debug.Log("Align triggered");
        Quaternion lookWhereYoureGoing;
        if (target != null)
        {
            Debug.Log(target);
            Vector3 direciton = Direction(target);
            lookWhereYoureGoing = Quaternion.LookRotation(direciton);
        }
        else

        {
            lookWhereYoureGoing = Quaternion.LookRotation(GetComponent<Rigidbody>().velocity.normalized);
        }
        transform.rotation = Quaternion.RotateTowards(transform.rotation, lookWhereYoureGoing, rotationSpeedRads);
    }

    void AlignBack(GameObject target)
    {
        Quaternion lookWhereYoureGoing;
        if (target != null)
        {
            Vector3 direciton = Direction(target);
            direciton = new Vector3(-direciton.x, 0, -direciton.z);
            lookWhereYoureGoing = Quaternion.LookRotation(direciton);
        }
        else

        {
            lookWhereYoureGoing = Quaternion.LookRotation(GetComponent<Rigidbody>().velocity.normalized);
        }
        transform.rotation = Quaternion.RotateTowards(transform.rotation, lookWhereYoureGoing, rotationSpeedRads);
    }

    void Align2(GameObject target)
    {
        Quaternion lookWhereYoureGoing;
        Vector3 goalFacing;
        if (target != null)
        {
            goalFacing = (target.transform.position - transform.position).normalized;


            goalRotationSpeedRads = maxRotationSpeedRads * (Vector3.Angle(goalFacing, this.transform.forward) / slowDownThreshold);

            if (rotationSpeedRads != 0.0f)
            {
                timeToTarget = Vector3.Angle(goalFacing, this.transform.forward) / rotationSpeedRads;
            }
            else
            {
                timeToTarget = 0.1f;
            }

            accelerationRads = (goalRotationSpeedRads - rotationSpeedRads) / timeToTarget;
            if (accelerationRads >= maxRotationAccelerationRads)
            {
                accelerationRads = maxRotationAccelerationRads;
            }

            rotationSpeedRads = rotationSpeedRads + (accelerationRads * Time.deltaTime);

            lookWhereYoureGoing = Quaternion.LookRotation(goalFacing, Vector3.up);
        }
        else
        {
            lookWhereYoureGoing = Quaternion.LookRotation(GetComponent<Rigidbody>().velocity.normalized);
        }

        transform.rotation = Quaternion.RotateTowards(transform.rotation, lookWhereYoureGoing, rotationSpeedRads);

    }

    void KinematicPursue(GameObject target)
    {
        Vector3 target_velocity = target.GetComponent<HumanCharBehaviour>().velocity;
        Vector3 target_new_position = target.transform.position + target_velocity * Time.deltaTime;
        Vector3 direction = Direction(target_new_position);
        gameObject.GetComponent<Rigidbody>().velocity = maxVelocityMagnitude * direction;
    }

}
