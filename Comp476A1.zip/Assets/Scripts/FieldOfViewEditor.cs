﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(BehaviorScript))]
public class NewBehaviourScript : Editor
{

    private void OnSceneGUI()
    {
        BehaviorScript fow = (BehaviorScript)target;
        Handles.color = Color.red;
        Handles.DrawWireArc(fow.transform.position, Vector3.up, Vector3.forward, 360, fow.viewRadius);
        Vector3 viewAngleA = fow.DirFromAngle(-fow.viewAngle / 2, false);
        Vector3 viewAngleB = fow.DirFromAngle(fow.viewAngle / 2, false);
        Handles.DrawLine(fow.transform.position, fow.transform.position + viewAngleA * fow.viewRadius);
        Handles.DrawLine(fow.transform.position, fow.transform.position + viewAngleB * fow.viewRadius);


        Handles.color = Color.blue;
        if (fow.Target != null)
        {
            Handles.DrawLine(fow.transform.position, fow.Target.transform.position);
        }

        Handles.color = Color.yellow;
        Handles.DrawLine(fow.transform.position, fow.transform.position + fow.GetComponent<Rigidbody>().velocity.normalized * 3);
    }
}