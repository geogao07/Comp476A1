﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Game : MonoBehaviour
{
    float TimeBetweenRounds = 4f;
    float Timer = 0;

    public int RunnerCount = 5;

    bool firstGame = true;
    bool gameStarted;
    
    void Start()
    {
    }

    
    void Update()
    {
        Timer += Time.deltaTime;
        if (Timer > 2f && !gameStarted)
        {
            StartGame();
            gameStarted = true;
        }

        CheckRoundEnd();
    }

    void StartGame()
    {
        //chek if it is the first round if not then start it
        if (!firstGame)
        {
            //reset
            Debug.Log("Preparing for next round");


            for (int i = 0; i < transform.childCount; i++)
            {
                transform.GetChild(i).GetComponent<BehaviorScript>().ResetStates();
                transform.GetChild(i).GetComponent<BehaviorScript>().ResetSpeeds();
                
            }

        }
        else
        {
            firstGame = false;
            Debug.Log("This is the first round");
        }


        //Choose a random NPC as tagged one
        int r = Random.Range(0, transform.childCount);
        GameObject target = transform.GetChild(r).gameObject;     
        target.GetComponent<BehaviorScript>().SetChaser();

        // Set others target to the chaser
        for (int i = 0; i < transform.childCount; i++)
        {
            if (transform.GetChild(i).transform.name != target.transform.name)
            {
                transform.GetChild(i).GetComponent<BehaviorScript>().SetFleeFromTarget(target.transform);
            }
        }
    }

    void CheckRoundEnd()
    {
        if (RunnerCount == 0)
        {
            gameStarted = false;
            Timer = 0;
            RunnerCount = 5;

            Debug.Log("This round ends, next round will start shortly");
        }
    }
}
