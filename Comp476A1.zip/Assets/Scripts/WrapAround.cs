﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WrapAround : MonoBehaviour
{
    private void OnCollisionEnter(Collision other)
    {
        //check if NPC collides with the wall
        Debug.Log("First detect");
        
        if (other.collider.tag == "NPC")
        {
            Vector3 pos = other.transform.position;
            //times -1 to x and z to wrap the plane
            pos.x *= -1;
            if (pos.x < 0)
                pos.x += 1f;
            else
                pos.x -= 1f;

            pos.z *= -1;
            if (pos.z < 0)
                pos.z += 1f;
            else
                pos.z -= 1f;

            other.transform.position = pos;
        }
    }
}
