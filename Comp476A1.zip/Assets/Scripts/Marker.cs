﻿using UnityEngine;
using System.Collections;

public class Marker : MonoBehaviour
{
    void SelfDestruct()
    {
        Destroy(gameObject);
    }
}
