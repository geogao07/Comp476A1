﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BehaviorScript : MonoBehaviour
{
    /*
     1. Chaser will chase the nearest target
     2. Fleet object will fleet right away if the chaser is close, otherwise
        it will align the direction and then fleet
     3. The object which is not fleeting will try to save the frozen target
     4. The chaser will get buffed after catching the first object (speed up)
     5. After catching all objects, the game will restart in a few seconds
         */
   
    // if chaser doesnt catch someone for a while, increase speed
    float chaseTimer = 0;
    float wanderTimer = 0;
    float unfreezeCheckTimer = 0;
    float unfreezeCheckTime;
    public float wanderChangeTime = 0.2f;             

    float fleetTimer = 0;

    //variables
    [Header("Field of View")]
    public float viewRadius;
    public float viewAngle;


    [Header("Color Material")]
    public Material Red_mat;
    public Material Black_mat;
    public Material Frozen_mat;


    [Header("State")]
    public bool tagged;
    public bool frozen;

    public enum npcType { Chasing, Fleeing };
    public npcType type = new npcType();

    [Header("Chasing")]
    public bool Kinematic_Seek;
   


    [Header("Fleeing")]
    public bool Always_Flee;
    public bool Allow_Unfreezing;
    
    //speed set ups and the rotation of wander
    public float speed = 5f;           
    public float WanderRotation = 15f;

    [Header("Target:")]
    public Transform Target;
    public Transform SecondaryTarget;
    
    public float align_Rotation_Speed;
    public bool AllowAnimations;
    
    void Start()
    {
        //random the speed
        speed += Random.Range(-1.5f, 1.5f);
        unfreezeCheckTime = Random.Range(1f, 4f);


    }

    // Update is called once per frame
    void Update()
    {



        //Map wrap kind of
        //if (transform.position.x >= 16.75 && GetComponent<Rigidbody>().velocity.normalized.x >= 0)
        //    transform.position = new Vector3(-27f, transform.position.y, transform.position.z);
        //else if (transform.position.x <= -27.5f && GetComponent<Rigidbody>().velocity.normalized.x <= 0)
        //    transform.position = new Vector3(16.5f, transform.position.y, transform.position.z);
        //else if (transform.position.z >= 14.9f && GetComponent<Rigidbody>().velocity.normalized.z >= 0)
        //    transform.position = new Vector3(transform.position.x, transform.position.y, -14.5f);
        //else if (transform.position.z <= -14.6f && GetComponent<Rigidbody>().velocity.normalized.z <= 0)
        //    transform.position = new Vector3(transform.position.x, transform.position.y, 14.8f);



        if (type + "" == "Chasing")
        {
            if (Target != null)
                Kinematic_SeekBehavior();
            else if (transform.parent.GetComponent<Game>().RunnerCount > 0)
                ChaserFindNewTarget();
        }
        else if (type + "" == "Fleeing" && !frozen)
        {
            if (Always_Flee && Target != null)
                Kinematic_FleeBehavior();
            else
                RunnerBehavior();
        }

        transform.position = new Vector3(transform.position.x, 1f, transform.position.z);


        
    }


  /**********************************************************************************************/

    // chase behaviors
    void Kinematic_SeekBehavior()
    {

        /*  character directly go towards it if distance is small
         * if the distance is large, the char will align first then move
         */
        Vector3 Dir = (Target.position - transform.position).normalized;            
        Vector3 seekVelocity = Dir * speed;                                         


        // Check Distance, if its larger, then check if you are facing the target.
        if (Vector3.Distance(Target.position, transform.position) < 10)
        {
            transform.position += seekVelocity * Time.deltaTime;
        }
        else
        {
            //make sure to check if you are facing your target.
            float angle = 10f;
            if (Vector3.Angle(transform.forward, (Target.position - transform.position)) < angle)
            {
                //allowed to move
                transform.position += seekVelocity * Time.deltaTime;
            }
            // other wise stop
            else
            {
                seekVelocity = Dir * 0f * speed;
                transform.position += seekVelocity * Time.deltaTime;
            }
        }



        //align orientation
        AlignOrientation(1);


       
        // every 5 seconds, find new target (so if anyone else is closer, chase them instead.)
        chaseTimer += Time.deltaTime;
        if (chaseTimer > 5f && chaseTimer < 5.10f)
            ChaserFindNewTarget();
        if (chaseTimer > 10f)
        {
            speed += 1f;
            chaseTimer = 0;
        }
    }



    // flee behaviors
    void Kinematic_FleeBehavior()
    {
        /*
         * If chaser is not actively chasing you, wander or unfreeze targets
         * if chaser is chasing you, flee
         */

        //get direction away from target, flee, face away 
        // Find Normalized Direction

        Vector3 Dir = (transform.position - Target.position).normalized;
        Vector3 fleeVelocity = Dir * speed;
       
        // Check Distance, if its larger, then check if you are facing the target.
        if (Vector3.Distance(Target.position, transform.position) < 8)

        {

            if (Vector3.Distance(Target.position, transform.position) < 5)
                transform.position += fleeVelocity * Time.deltaTime;

            else {
                AlignOrientation(2);
                transform.position += fleeVelocity * Time.deltaTime;
            }
        }
        else
        {
            Kinematic_WanderBehavior();
            
        }
        

    }


    void Kinematic_WanderBehavior()
    {
        // randomly change orientations by a fixed value multiplied by random(-1,+1)
        // translate on forward axis

        //if too close to the chaser , it should flee to avoid being frozen

        if (Target!=null && Vector3.Distance(Target.position, transform.position) < 5)

        {
            Kinematic_FleeBehavior();

        }

        else
        {
            wanderTimer += Time.deltaTime;
            if (wanderTimer > wanderChangeTime)
            {
                float r = Random.Range(-1f, 1f);
                r *= WanderRotation;
                r *= 50;

                transform.Rotate(new Vector3(0, r * Time.deltaTime, 0));
                wanderTimer = 0;
            }

            Vector3 wanderDirectionSpeed = speed * transform.forward;
            transform.position += wanderDirectionSpeed * Time.deltaTime;
        }
    }


    // arrive behavior
    void Kinematic_ArriveBehavior()
    {
        // satisfaction r1, r2
        // if distance> r1, speed is full speed
        // if distance is less than r1 but greater than
        //  r2,the speed is decreased depend on the distance
        // if inside r2, stop .

        //if too close to the chaser , it should flee to avoid being frozen
        if (Target != null && Vector3.Distance(Target.position,transform.position)<5)

        {
            Kinematic_FleeBehavior();
        }

        // if someone else unfreezes a target.
        if (!SecondaryTarget.GetComponent<BehaviorScript>().frozen)                  
            SecondaryTarget = null;
        else
        {
            float radius1 = 20f;
            float radius2 = 2f;

            Vector3 arriveVelocity;

            if (SecondaryTarget != null)
            {
                float distanceToTarget = Vector3.Distance(transform.position, SecondaryTarget.position);
                Vector3 Dir = (SecondaryTarget.position - transform.position).normalized;

                if (distanceToTarget > radius1)
                {
                    arriveVelocity = Dir * speed;
                }
                else if (distanceToTarget < radius1 && distanceToTarget > radius2)
                {
                    // go slower depending on the distance.
                    float speedFactor = (distanceToTarget / 10f) / 2f;
                  
                    arriveVelocity = Dir * speed * speedFactor;
                }
                else
                {
                    arriveVelocity = Vector3.zero;
                }

                transform.position += arriveVelocity * Time.deltaTime;
                AlignOrientation(4);

                
            }
            else
            {
                Debug.Log("Secondary Target is NULL");
            }
        }
    }


    // runner behavior
    void RunnerBehavior()
    {
        // wander or unfreeze the frozen one when the object is not being chasing
        if (Target == null)
        {
            Kinematic_WanderBehavior();
        }
        else
        {
            // if targeted by the chaser, flee
            // else wander
            Transform obj = Target.GetComponent<BehaviorScript>().Target;

            if (obj == null)
            {
                Kinematic_WanderBehavior();
            }
            else if (obj.name == transform.name || Always_Flee)
            {
                Kinematic_FleeBehavior();
            }
            else if (Allow_Unfreezing && SecondaryTarget == null)
            {

                unfreezeCheckTimer += Time.deltaTime;
                if (unfreezeCheckTimer > unfreezeCheckTime)
                {
                    
                    unfreezeCheckTimer = 0;
                    FindUnfreezeTarget();
                }
                else
                {
                    Kinematic_WanderBehavior();
                }
            }
            else if (SecondaryTarget != null)
            {
                Kinematic_ArriveBehavior();
            }
            else
            {
                Kinematic_WanderBehavior();
            }
        }
    }


    void FindUnfreezeTarget()
    {
        Collider[] temp = Physics.OverlapSphere(transform.position, 100f);
        // find closest
        Collider UnfreezeTarget = null;
        foreach (Collider c in temp)
        {
            if (c.transform.tag == "NPC" && c.GetComponent<BehaviorScript>().type + "" == "Fleeing" && c.GetComponent<BehaviorScript>().frozen)
            {
                UnfreezeTarget = c;
                SecondaryTarget = c.transform;
                //Debug.Log("Secondary Target Assigned " + SecondaryTarget.transform.name + "! for Runner: " + transform.name);
                break;
            }
        }
    }

    void AlignOrientation(int id)   // if id==1, face towards, if id==2, face away, if id==3, face in forward direction, if id==4, face secondary target
    {
        // get direction
        Quaternion lookDirection;
        Vector3 Dir;

        //get direction towards target:
        if (id == 1)
            Dir = (Target.position - transform.position).normalized;
        else if (id == 2)
            Dir = (transform.position - Target.position).normalized;
        else if (id == 3)
            Dir = transform.forward;
        else
            Dir = (SecondaryTarget.position - transform.position).normalized;
        //set quaternion to this dir
        lookDirection = Quaternion.LookRotation(Dir, Vector3.up);
        transform.rotation = Quaternion.RotateTowards(transform.rotation, lookDirection, align_Rotation_Speed);

    }


    /***************************************************************************************************************/


    // Chaser to find new object to chase
    public void ChaserFindNewTarget()
    {
        Collider[] temp = Physics.OverlapSphere(transform.position, 100f);
        // find the closest target
        float shortestDistance = 1000;
        Collider shortestTarget = null;
        foreach (Collider c in temp)
        {
            if (Vector3.Distance(transform.position, c.transform.position) < shortestDistance
                && c.transform.tag == "NPC" && c.GetComponent<BehaviorScript>().type + "" == "Fleeing" && !c.GetComponent<BehaviorScript>().frozen)
            {
                //Debug.Log("Potential Target: "+c.transform.name);
                if (!c.gameObject.GetComponent<BehaviorScript>().frozen)
                {
                    shortestDistance = Vector3.Distance(transform.position, c.transform.position);
                    shortestTarget = c;
                }
            }
        }
        // we know shortest target now, seek that target
        if (shortestTarget != null)
            Target = shortestTarget.transform;
    }



    // freeze tag methods
    public void SetChaser()
    {
        tagged = true;
        type = npcType.Chasing;
        
        transform.GetChild(2).GetComponent<Renderer>().material = Red_mat;
        transform.GetChild(3).GetComponent<Renderer>().material = Red_mat;
        Debug.Log("Chaser set: " + transform.name);
        Target = null;

        //give a speed boost
        speed += 1f;

        
    }

    public void SetFleeFromTarget(Transform target)
    {
        Target = target;
    }

    public void SetFrozen()
    {
        frozen = true;
        
        transform.GetChild(2).GetComponent<Renderer>().material = Frozen_mat;
        transform.GetChild(3).GetComponent<Renderer>().material = Frozen_mat;
        
    }
    //For field of view
    public Vector3 DirFromAngle(float angle, bool angleIsGlobal)
    {
        if (!angleIsGlobal)
        {
            angle += transform.eulerAngles.y;
        }
        return new Vector3(Mathf.Sin(angle * Mathf.Deg2Rad), 0, Mathf.Cos(angle * Mathf.Deg2Rad));
    }


    //reinit
    public void ResetStates()
    {
        frozen = false;
        tagged = false;
        type = npcType.Fleeing;
        transform.GetChild(2).GetComponent<Renderer>().material = Black_mat;
        transform.GetChild(3).GetComponent<Renderer>().material = Black_mat;

        

        
    }

    public void ResetSpeeds()
    {
        speed = 5;
        speed += Random.Range(-1.5f, 1.5f);
    }





    // collision
    private void OnCollisionEnter(Collision collision)
    {
        if (type + "" == "Chasing")
        {
            if (collision.collider.tag == "NPC" && !collision.collider.GetComponent<BehaviorScript>().frozen)
            {
                
                collision.collider.GetComponent<BehaviorScript>().SetFrozen();
                Target = null;

                //update counter in game.cs
                transform.parent.GetComponent<Game>().RunnerCount -= 1;

                // get faster everytime you catch someone
                speed += 1f;

                chaseTimer = 0;

                GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
        }
        else if (type + "" == "Fleeing" && Allow_Unfreezing)
        {
            if (collision.collider.tag == "NPC" && collision.collider.GetComponent<BehaviorScript>().frozen)
            {
                collision.collider.GetComponent<BehaviorScript>().ResetStates();
                transform.parent.GetComponent<Game>().RunnerCount += 1;
                SecondaryTarget = null;
            }
        }
    }
}
